package com.example.demo.app

class CustomColor {
    companion object{
        var point :String = "#D20C9B"
        var background : String = "#232323"
        var deepBackground : String ="#1A1A1A"
        var white : String ="#FFFFFF"
        var black : String ="#000000"
        var purple : String ="#8769BA"
    }
}