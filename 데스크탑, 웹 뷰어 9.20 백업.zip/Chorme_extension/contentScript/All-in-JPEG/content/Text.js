export default class Text {
    constructor(_data, _contentAttribute){
        this.data = _data;
        this.contentAttribute = _contentAttribute
    }
}
